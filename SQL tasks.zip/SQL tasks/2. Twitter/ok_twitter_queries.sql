USE ok_twitter;

-- 2.1. Вывести последние 5 опубликованных твитов.

SELECT twit, post_date AS posted FROM twits
ORDER BY post_date DESC
LIMIT 5;

-- 2.2. Вывести средний возраст всех пользователей твиттера.

SELECT ROUND(YEAR(NOW())-AVG(YEAR(birth_date))) AS 'average age' FROM users;

-- 2.3. Вывести к-во follower-ов для каждого пользователя.

SELECT u.first_name, u.last_name, COUNT(f.follower_id) AS 'count' 
FROM followers f
LEFT JOIN users u USING (user_id)
GROUP BY user_id
ORDER BY u.first_name;

-- 2.4. Вывести пользователей, у которых есть хотя бы один fоllоwеr.

SELECT DISTINCT u.user_id, u.first_name, u.last_name, 'yes' AS has_followers
FROM followers f
LEFT JOIN users u USING (user_id)
ORDER BY u.user_id;

-- 2.5. Вывести к-во комментариев для каждого твита.

SELECT t.twit_id, t.twit, COUNT(c.comment_id) 'comments'
FROM twits t
LEFT JOIN comments c USING (twit_id)
GROUP BY twit_id;

-- 2.6. Вывести все твиты (включая все твиты follower-ов) для данного пользователя, отсортированные по дате публикации (последние сверху). (!)

SELECT t.twit_id,t.twit, t.post_date
FROM twits t
WHERE t.user_id = 22
UNION
SELECT t.twit_id, t.twit, t.post_date 
FROM twits t
JOIN followers f USING (user_id)
WHERE f.follower_id IN (SELECT f.follower_id FROM followers f WHERE user_id = 22)
ORDER BY post_date DESC;

-- 2.7. Вывести все комментарии, которые были опубликованы за последние 10 часов. (!)

SELECT * FROM comments
WHERE HOUR(creation_date) >= HOUR(NOW()) - INTERVAL 10 HOUR;

